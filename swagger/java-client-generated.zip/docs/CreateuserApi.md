# CreateuserApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createUser**](CreateuserApi.md#createUser) | **POST** /user | Create user


<a name="createUser"></a>
# **createUser**
> PhoneNumber createUser(user)

Create user

This can only be done by the logged in user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CreateuserApi;


CreateuserApi apiInstance = new CreateuserApi();
User user = new User(); // User | Created user object
try {
    PhoneNumber result = apiInstance.createUser(user);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CreateuserApi#createUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**User**](User.md)| Created user object |

### Return type

[**PhoneNumber**](PhoneNumber.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

