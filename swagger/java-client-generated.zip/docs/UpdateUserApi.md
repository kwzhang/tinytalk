# UpdateUserApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUser**](UpdateUserApi.md#updateUser) | **PUT** /user | Update user


<a name="updateUser"></a>
# **updateUser**
> updateUser(xPhoneNumber, xPassword, user)

Update user

This can only be done by the logged in user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UpdateUserApi;


UpdateUserApi apiInstance = new UpdateUserApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
User user = new User(); // User | Updated user object
try {
    apiInstance.updateUser(xPhoneNumber, xPassword, user);
} catch (ApiException e) {
    System.err.println("Exception when calling UpdateUserApi#updateUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **user** | [**User**](User.md)| Updated user object |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

