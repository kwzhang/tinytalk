
# CreditCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **String** |  |  [optional]
**expirationDate** | **String** |  |  [optional]
**validationCode** | **String** |  |  [optional]



