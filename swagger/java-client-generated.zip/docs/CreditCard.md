
# CreditCard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **String** |  |  [optional]
**expirationdate** | **String** |  |  [optional]
**validationcode** | **String** |  |  [optional]



