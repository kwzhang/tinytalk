
# UpdatePhoneIp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phonenumber** | **String** |  |  [optional]
**ip** | **String** |  |  [optional]



