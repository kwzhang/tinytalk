
# UpdatePhoneIp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip** | **String** |  |  [optional]



