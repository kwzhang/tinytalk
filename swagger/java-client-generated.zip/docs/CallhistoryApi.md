# CallhistoryApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callHistory**](CallhistoryApi.md#callHistory) | **POST** /callhistory | Request call history for specified phone number


<a name="callHistory"></a>
# **callHistory**
> List&lt;CallHistoryResponse&gt; callHistory(callHistoryRequest)

Request call history for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CallhistoryApi;


CallhistoryApi apiInstance = new CallhistoryApi();
CallHistoryRequest callHistoryRequest = new CallHistoryRequest(); // CallHistoryRequest | User phone number and period
try {
    List<CallHistoryResponse> result = apiInstance.callHistory(callHistoryRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CallhistoryApi#callHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **callHistoryRequest** | [**CallHistoryRequest**](CallHistoryRequest.md)| User phone number and period |

### Return type

[**List&lt;CallHistoryResponse&gt;**](CallHistoryResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

