
# TxtMsgResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**ResultEnum**](#ResultEnum) |  |  [optional]


<a name="ResultEnum"></a>
## Enum: ResultEnum
Name | Value
---- | -----
SUCCESS | &quot;success&quot;
PENDING | &quot;pending&quot;



