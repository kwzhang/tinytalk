
# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**address** | **String** |  |  [optional]
**creditcard** | [**CreditCard**](CreditCard.md) |  |  [optional]



