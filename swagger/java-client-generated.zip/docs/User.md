
# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**address** | **String** |  |  [optional]
**creditCard** | [**CreditCard**](CreditCard.md) |  |  [optional]



