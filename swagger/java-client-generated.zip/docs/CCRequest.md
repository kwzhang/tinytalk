
# CCRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**members** | **List&lt;String&gt;** |  |  [optional]
**startdatetime** | **String** |  |  [optional]
**duration** | **Integer** | time duration (in minutes) |  [optional]



