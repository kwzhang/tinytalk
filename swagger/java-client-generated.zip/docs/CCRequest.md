
# CCRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**members** | **List&lt;String&gt;** |  |  [optional]
**startdate** | **String** |  |  [optional]
**duration** | **Integer** | time duration (in minutes) |  [optional]



