# DialResponseApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dialResponse**](DialResponseApi.md#dialResponse) | **POST** /dialresponse/{response} | Response of call receiver


<a name="dialResponse"></a>
# **dialResponse**
> dialResponse(xPhoneNumber, xPassword, response)

Response of call receiver

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DialResponseApi;


DialResponseApi apiInstance = new DialResponseApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
String response = "response_example"; // String | 
try {
    apiInstance.dialResponse(xPhoneNumber, xPassword, response);
} catch (ApiException e) {
    System.err.println("Exception when calling DialResponseApi#dialResponse");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **response** | **String**|  | [enum: accept, busy, deny]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

