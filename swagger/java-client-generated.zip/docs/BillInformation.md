
# BillInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**incallTime** | **Integer** |  |  [optional]
**outcallTime** | **Integer** |  |  [optional]
**sendMsgBytes** | **Integer** |  |  [optional]
**receiveMsgBytes** | **Integer** |  |  [optional]
**cost** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



