
# TxtMsgRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sender** | **String** |  |  [optional]
**reciever** | **String** |  |  [optional]
**msg** | **String** |  |  [optional]



