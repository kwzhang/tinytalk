
# TxtMsgRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**receiver** | **String** |  |  [optional]
**msg** | **String** |  |  [optional]



