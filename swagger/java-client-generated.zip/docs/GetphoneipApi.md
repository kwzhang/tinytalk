# GetphoneipApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**phoneip**](GetphoneipApi.md#phoneip) | **GET** /phoneip/{phonenumber} | Request phoneip for specified phone number


<a name="phoneip"></a>
# **phoneip**
> PhoneIp phoneip(phonenumber)

Request phoneip for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.GetphoneipApi;


GetphoneipApi apiInstance = new GetphoneipApi();
String phonenumber = "phonenumber_example"; // String | 
try {
    PhoneIp result = apiInstance.phoneip(phonenumber);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GetphoneipApi#phoneip");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **phonenumber** | **String**|  |

### Return type

[**PhoneIp**](PhoneIp.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

