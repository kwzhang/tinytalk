# CcRequestApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ccRequest**](CcRequestApi.md#ccRequest) | **POST** /ccrequest | Send request for conference call


<a name="ccRequest"></a>
# **ccRequest**
> ccRequest(xPhoneNumber, xPassword, ccrequest)

Send request for conference call

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CcRequestApi;


CcRequestApi apiInstance = new CcRequestApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
CCRequestInformation ccrequest = new CCRequestInformation(); // CCRequestInformation | Conference call request
try {
    apiInstance.ccRequest(xPhoneNumber, xPassword, ccrequest);
} catch (ApiException e) {
    System.err.println("Exception when calling CcRequestApi#ccRequest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **ccrequest** | [**CCRequestInformation**](CCRequestInformation.md)| Conference call request |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

