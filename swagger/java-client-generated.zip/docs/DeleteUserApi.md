# DeleteUserApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteUser**](DeleteUserApi.md#deleteUser) | **DELETE** /user | Delete user for specified phone number


<a name="deleteUser"></a>
# **deleteUser**
> deleteUser(xPhoneNumber, xPassword)

Delete user for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DeleteUserApi;


DeleteUserApi apiInstance = new DeleteUserApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
try {
    apiInstance.deleteUser(xPhoneNumber, xPassword);
} catch (ApiException e) {
    System.err.println("Exception when calling DeleteUserApi#deleteUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

