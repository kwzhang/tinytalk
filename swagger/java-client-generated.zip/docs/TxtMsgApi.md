# TxtMsgApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**txtMsg**](TxtMsgApi.md#txtMsg) | **POST** /txtmsg | Send text message


<a name="txtMsg"></a>
# **txtMsg**
> txtMsg(xPhoneNumber, xPassword, body)

Send text message

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TxtMsgApi;


TxtMsgApi apiInstance = new TxtMsgApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
TxtMsgRequest body = new TxtMsgRequest(); // TxtMsgRequest | Text message
try {
    apiInstance.txtMsg(xPhoneNumber, xPassword, body);
} catch (ApiException e) {
    System.err.println("Exception when calling TxtMsgApi#txtMsg");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **body** | [**TxtMsgRequest**](TxtMsgRequest.md)| Text message |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

