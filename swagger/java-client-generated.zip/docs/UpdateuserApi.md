# UpdateuserApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUser**](UpdateuserApi.md#updateUser) | **PUT** /user | Update user


<a name="updateUser"></a>
# **updateUser**
> updateUser(user)

Update user

This can only be done by the logged in user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UpdateuserApi;


UpdateuserApi apiInstance = new UpdateuserApi();
User user = new User(); // User | Updated user object
try {
    apiInstance.updateUser(user);
} catch (ApiException e) {
    System.err.println("Exception when calling UpdateuserApi#updateUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**User**](User.md)| Updated user object |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

