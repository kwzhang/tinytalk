# UpdatePhoneIpApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updatePhoneIp**](UpdatePhoneIpApi.md#updatePhoneIp) | **PUT** /phoneip | Update phoneip for specified phone number


<a name="updatePhoneIp"></a>
# **updatePhoneIp**
> updatePhoneIp(xPhoneNumber, xPassword, updatePhoneIp)

Update phoneip for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UpdatePhoneIpApi;


UpdatePhoneIpApi apiInstance = new UpdatePhoneIpApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
UpdatePhoneIp updatePhoneIp = new UpdatePhoneIp(); // UpdatePhoneIp | User phone number and new ip
try {
    apiInstance.updatePhoneIp(xPhoneNumber, xPassword, updatePhoneIp);
} catch (ApiException e) {
    System.err.println("Exception when calling UpdatePhoneIpApi#updatePhoneIp");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **updatePhoneIp** | [**UpdatePhoneIp**](UpdatePhoneIp.md)| User phone number and new ip |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

