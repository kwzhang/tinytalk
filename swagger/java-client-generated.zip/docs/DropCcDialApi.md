# DropCcDialApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**dropCcDial**](DropCcDialApi.md#dropCcDial) | **DELETE** /ccdial/{ccnumber} | Dial to conference call number


<a name="dropCcDial"></a>
# **dropCcDial**
> dropCcDial(xPhoneNumber, xPassword, ccnumber)

Dial to conference call number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DropCcDialApi;


DropCcDialApi apiInstance = new DropCcDialApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
String ccnumber = "ccnumber_example"; // String | 
try {
    apiInstance.dropCcDial(xPhoneNumber, xPassword, ccnumber);
} catch (ApiException e) {
    System.err.println("Exception when calling DropCcDialApi#dropCcDial");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **ccnumber** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

