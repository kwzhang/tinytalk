# CallCcDialApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callCcDial**](CallCcDialApi.md#callCcDial) | **POST** /ccdial/{ccnumber} | Dial to conference call number


<a name="callCcDial"></a>
# **callCcDial**
> InlineResponse200 callCcDial(xPhoneNumber, xPassword, ccnumber)

Dial to conference call number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CallCcDialApi;


CallCcDialApi apiInstance = new CallCcDialApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
String ccnumber = "ccnumber_example"; // String | 
try {
    InlineResponse200 result = apiInstance.callCcDial(xPhoneNumber, xPassword, ccnumber);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CallCcDialApi#callCcDial");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **ccnumber** | **String**|  |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

