# PhoneipApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**phoneip**](PhoneipApi.md#phoneip) | **GET** /phoneip/{phonenumber} | Request phoneip for specified phone number


<a name="phoneip"></a>
# **phoneip**
> String phoneip(phonenumber)

Request phoneip for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PhoneipApi;


PhoneipApi apiInstance = new PhoneipApi();
String phonenumber = "phonenumber_example"; // String | 
try {
    String result = apiInstance.phoneip(phonenumber);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PhoneipApi#phoneip");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **phonenumber** | **String**|  |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

