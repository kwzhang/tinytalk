
# NewPasswordInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phonenumber** | **String** |  |  [optional]
**oldpassword** | **String** |  |  [optional]
**newpassword** | **String** |  |  [optional]



