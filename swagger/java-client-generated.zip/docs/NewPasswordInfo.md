
# NewPasswordInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oldPassword** | **String** |  |  [optional]
**newPassword** | **String** |  |  [optional]



