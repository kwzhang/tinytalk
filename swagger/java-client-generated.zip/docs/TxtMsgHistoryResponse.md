
# TxtMsgHistoryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentbytes** | **Integer** |  |  [optional]
**recievebytes** | **Integer** |  |  [optional]
**cost** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



