
# TxtMsgHistoryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentBytes** | **Integer** |  |  [optional]
**receiveBytes** | **Integer** |  |  [optional]
**cost** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



