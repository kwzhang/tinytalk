# BillApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bill**](BillApi.md#bill) | **GET** /bill | Request billing information


<a name="bill"></a>
# **bill**
> BillInformation bill(xPhoneNumber, xPassword, period)

Request billing information

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BillApi;


BillApi apiInstance = new BillApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
String period = "period_example"; // String | 
try {
    BillInformation result = apiInstance.bill(xPhoneNumber, xPassword, period);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BillApi#bill");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **period** | **String**|  |

### Return type

[**BillInformation**](BillInformation.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

