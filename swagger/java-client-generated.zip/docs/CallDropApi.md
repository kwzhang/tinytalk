# CallDropApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callDrop**](CallDropApi.md#callDrop) | **DELETE** /dial | Drop call


<a name="callDrop"></a>
# **callDrop**
> callDrop(xPhoneNumber, xPassword)

Drop call

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CallDropApi;


CallDropApi apiInstance = new CallDropApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
try {
    apiInstance.callDrop(xPhoneNumber, xPassword);
} catch (ApiException e) {
    System.err.println("Exception when calling CallDropApi#callDrop");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

