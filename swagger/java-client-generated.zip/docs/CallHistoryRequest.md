
# CallHistoryRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phonenumber** | **String** |  |  [optional]
**period** | **String** |  |  [optional]



