# ChangePasswordApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**changePassword**](ChangePasswordApi.md#changePassword) | **PUT** /user/password | change user password


<a name="changePassword"></a>
# **changePassword**
> changePassword(xPhoneNumber, xPassword, newPasswordInfo)

change user password

This can only be done by the logged in user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ChangePasswordApi;


ChangePasswordApi apiInstance = new ChangePasswordApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
NewPasswordInfo newPasswordInfo = new NewPasswordInfo(); // NewPasswordInfo | User phone number to change password
try {
    apiInstance.changePassword(xPhoneNumber, xPassword, newPasswordInfo);
} catch (ApiException e) {
    System.err.println("Exception when calling ChangePasswordApi#changePassword");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **newPasswordInfo** | [**NewPasswordInfo**](NewPasswordInfo.md)| User phone number to change password |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

