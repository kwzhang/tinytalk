# TxtmsghistoryApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**txtMsgHistory**](TxtmsghistoryApi.md#txtMsgHistory) | **POST** /txtmsghistory | Request text msg history for specified phone number


<a name="txtMsgHistory"></a>
# **txtMsgHistory**
> TxtMsgHistoryResponse txtMsgHistory(txtMsgHistoryRequest)

Request text msg history for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TxtmsghistoryApi;


TxtmsghistoryApi apiInstance = new TxtmsghistoryApi();
TxtMsgHistoryRequest txtMsgHistoryRequest = new TxtMsgHistoryRequest(); // TxtMsgHistoryRequest | User phone number and period
try {
    TxtMsgHistoryResponse result = apiInstance.txtMsgHistory(txtMsgHistoryRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TxtmsghistoryApi#txtMsgHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **txtMsgHistoryRequest** | [**TxtMsgHistoryRequest**](TxtMsgHistoryRequest.md)| User phone number and period |

### Return type

[**TxtMsgHistoryResponse**](TxtMsgHistoryResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

