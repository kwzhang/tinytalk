# DeleteuserApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteuser**](DeleteuserApi.md#deleteuser) | **DELETE** /user/{phonenumber} | Delete user for specified phone number


<a name="deleteuser"></a>
# **deleteuser**
> deleteuser(phonenumber)

Delete user for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DeleteuserApi;


DeleteuserApi apiInstance = new DeleteuserApi();
String phonenumber = "phonenumber_example"; // String | 
try {
    apiInstance.deleteuser(phonenumber);
} catch (ApiException e) {
    System.err.println("Exception when calling DeleteuserApi#deleteuser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **phonenumber** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

