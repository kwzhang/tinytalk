
# CallHistoryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inout** | **String** |  |  [optional]
**phonenumber** | **String** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**cost** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



