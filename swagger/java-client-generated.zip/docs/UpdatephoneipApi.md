# UpdatephoneipApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updatephoneip**](UpdatephoneipApi.md#updatephoneip) | **PUT** /phoneip | Update phoneip for specified phone number


<a name="updatephoneip"></a>
# **updatephoneip**
> updatephoneip(updatePhoneIp)

Update phoneip for specified phone number

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UpdatephoneipApi;


UpdatephoneipApi apiInstance = new UpdatephoneipApi();
UpdatePhoneIp updatePhoneIp = new UpdatePhoneIp(); // UpdatePhoneIp | User phone number and new ip
try {
    apiInstance.updatephoneip(updatePhoneIp);
} catch (ApiException e) {
    System.err.println("Exception when calling UpdatephoneipApi#updatephoneip");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **updatePhoneIp** | [**UpdatePhoneIp**](UpdatePhoneIp.md)| User phone number and new ip |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

