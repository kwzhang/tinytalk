# TxtmsgApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**txtMsg**](TxtmsgApi.md#txtMsg) | **POST** /txtmsg | Send text message


<a name="txtMsg"></a>
# **txtMsg**
> TxtMsgResult txtMsg(body)

Send text message

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TxtmsgApi;


TxtmsgApi apiInstance = new TxtmsgApi();
TxtMsgRequest body = new TxtMsgRequest(); // TxtMsgRequest | Text message
try {
    TxtMsgResult result = apiInstance.txtMsg(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TxtmsgApi#txtMsg");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TxtMsgRequest**](TxtMsgRequest.md)| Text message |

### Return type

[**TxtMsgResult**](TxtMsgResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

