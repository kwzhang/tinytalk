# ChangepasswordApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**changePassword**](ChangepasswordApi.md#changePassword) | **POST** /changepassword | change user password


<a name="changePassword"></a>
# **changePassword**
> changePassword(newPasswordInfo)

change user password

This can only be done by the logged in user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ChangepasswordApi;


ChangepasswordApi apiInstance = new ChangepasswordApi();
NewPasswordInfo newPasswordInfo = new NewPasswordInfo(); // NewPasswordInfo | User phone number to change password
try {
    apiInstance.changePassword(newPasswordInfo);
} catch (ApiException e) {
    System.err.println("Exception when calling ChangepasswordApi#changePassword");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **newPasswordInfo** | [**NewPasswordInfo**](NewPasswordInfo.md)| User phone number to change password |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

