
# CCRequestInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**members** | **List&lt;String&gt;** |  |  [optional]
**startDatetime** | **String** |  |  [optional]
**endDatetime** | **String** | time duration (in minutes) |  [optional]



