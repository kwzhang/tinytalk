# DialApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callDial**](DialApi.md#callDial) | **POST** /dial | Dial voice call


<a name="callDial"></a>
# **callDial**
> callDial(xPhoneNumber, xPassword, dialRquest)

Dial voice call

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DialApi;


DialApi apiInstance = new DialApi();
String xPhoneNumber = "xPhoneNumber_example"; // String | 
String xPassword = "xPassword_example"; // String | 
DialRquest dialRquest = new DialRquest(); // DialRquest | 
try {
    apiInstance.callDial(xPhoneNumber, xPassword, dialRquest);
} catch (ApiException e) {
    System.err.println("Exception when calling DialApi#callDial");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xPhoneNumber** | **String**|  |
 **xPassword** | **String**|  |
 **dialRquest** | [**DialRquest**](DialRquest.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

