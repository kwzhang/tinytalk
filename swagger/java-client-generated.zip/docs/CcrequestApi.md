# CcrequestApi

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ccRequest**](CcrequestApi.md#ccRequest) | **POST** /ccrequest | Send request for conference call


<a name="ccRequest"></a>
# **ccRequest**
> PhoneNumber ccRequest(body)

Send request for conference call

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CcrequestApi;


CcrequestApi apiInstance = new CcrequestApi();
CCRequest body = new CCRequest(); // CCRequest | Conference call request
try {
    PhoneNumber result = apiInstance.ccRequest(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CcrequestApi#ccRequest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CCRequest**](CCRequest.md)| Conference call request |

### Return type

[**PhoneNumber**](PhoneNumber.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

