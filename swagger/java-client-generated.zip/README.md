# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.BillApi;

import java.io.File;
import java.util.*;

public class BillApiExample {

    public static void main(String[] args) {
        
        BillApi apiInstance = new BillApi();
        String xPhoneNumber = "xPhoneNumber_example"; // String | 
        String xPassword = "xPassword_example"; // String | 
        String period = "period_example"; // String | 
        try {
            BillInformation result = apiInstance.bill(xPhoneNumber, xPassword, period);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling BillApi#bill");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://virtserver.swaggerhub.com/SWArchi2018_3/designcraft/1.0.0*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*BillApi* | [**bill**](docs/BillApi.md#bill) | **GET** /bill | Request billing information
*CallCcDialApi* | [**callCcDial**](docs/CallCcDialApi.md#callCcDial) | **POST** /ccdial/{ccnumber} | Dial to conference call number
*CallDropApi* | [**callDrop**](docs/CallDropApi.md#callDrop) | **DELETE** /dial | Drop call
*CcRequestApi* | [**ccRequest**](docs/CcRequestApi.md#ccRequest) | **POST** /ccrequest | Send request for conference call
*ChangePasswordApi* | [**changePassword**](docs/ChangePasswordApi.md#changePassword) | **PUT** /user/password | change user password
*CreateUserApi* | [**createUser**](docs/CreateUserApi.md#createUser) | **POST** /user | Create user
*DeleteUserApi* | [**deleteUser**](docs/DeleteUserApi.md#deleteUser) | **DELETE** /user | Delete user for specified phone number
*DialApi* | [**callDial**](docs/DialApi.md#callDial) | **POST** /dial | Dial voice call
*DialResponseApi* | [**dialResponse**](docs/DialResponseApi.md#dialResponse) | **POST** /dialresponse/{response} | Response of call receiver
*DropCcDialApi* | [**dropCcDial**](docs/DropCcDialApi.md#dropCcDial) | **DELETE** /ccdial/{ccnumber} | Dial to conference call number
*TxtMsgApi* | [**txtMsg**](docs/TxtMsgApi.md#txtMsg) | **POST** /txtmsg | Send text message
*UpdatePhoneIpApi* | [**updatePhoneIp**](docs/UpdatePhoneIpApi.md#updatePhoneIp) | **PUT** /phoneip | Update phoneip for specified phone number
*UpdateUserApi* | [**updateUser**](docs/UpdateUserApi.md#updateUser) | **PUT** /user | Update user


## Documentation for Models

 - [BillInformation](docs/BillInformation.md)
 - [CCRequestInformation](docs/CCRequestInformation.md)
 - [CallHistoryResponse](docs/CallHistoryResponse.md)
 - [CreditCard](docs/CreditCard.md)
 - [DialRquest](docs/DialRquest.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [NewPasswordInfo](docs/NewPasswordInfo.md)
 - [PhoneNumber](docs/PhoneNumber.md)
 - [TxtMsgHistoryResponse](docs/TxtMsgHistoryResponse.md)
 - [TxtMsgRequest](docs/TxtMsgRequest.md)
 - [UpdatePhoneIp](docs/UpdatePhoneIp.md)
 - [User](docs/User.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### api_key

- **Type**: API key
- **API key parameter name**: api_key
- **Location**: HTTP header

### petstore_auth

- **Type**: OAuth
- **Flow**: implicit
- **Authorization URL**: http://petstore.swagger.io/oauth/dialog
- **Scopes**: 
  - write:pets: modify pets in your account
  - read:pets: read your pets


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author

apiteam@swagger.io

