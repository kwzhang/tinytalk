package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.User;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for CreateuserApi
 */
@Ignore
public class CreateuserApiTest {

    private final CreateuserApi api = new CreateuserApi();

    
    /**
     * Create user
     *
     * This can only be done by the logged in user.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void createUserTest() throws ApiException {
        User body = null;
        String response = api.createUser(body);

        // TODO: test validations
    }
    
}
