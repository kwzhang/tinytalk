<?php
$period = $_POST["period"];
$incall = $_POST["incall"];
$outcall = $_POST["outcall"];
$sentbytes = $_POST["sentbytes"];
$receivedbytes = $_POST["receivedbytes"];

require "../predis/autoload.php";
Predis\Autoloader::register();
$redis = new Predis\Client();

$redis->hset("PRICE:".$period, "incall", $incall);
$redis->hset("PRICE:".$period, "outcall", $outcall);
$redis->hset("PRICE:".$period, "sentBytes", $sentbytes);
$redis->hset("PRICE:".$period, "receivedBytes", $receivedbytes);
?>
<script>
    window.location.replace("admin.php");
</script>