<?php
require "../predis/autoload.php";
Predis\Autoloader::register();
$redis = new Predis\Client();

$operation = $_GET["op"];
$phoneNumber = $_GET["user"];

if ($operation == "enable") {
	$redis->hset("user:".$phoneNumber, "status", "enable");
}
else if ($operation == "disable") {
	$redis->hset("user:".$phoneNumber, "status", "disable");
}
else if ($operation == "delete") {
	$redis->del("user:".$phoneNumber);
}
?>
<script>
    window.location.replace("admin.php");
</script>