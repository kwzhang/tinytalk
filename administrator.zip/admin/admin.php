<?php
require "../predis/autoload.php";
Predis\Autoloader::register();
$redis = new Predis\Client();

$users = $redis->keys("user:*");
?>
<html>
<link href='../styles.css' rel='stylesheet'>
<body>
<p>
<table width="100%">
<tr>
<td><h1>Administrator Page</h1></td>
<td><image src="designCraft-logo.jpg" width="180" height="100"/></td>
</tr>
</table>
<?php
date_default_timezone_set('america/new_york');
$period = date('Ym');
$incall = $redis->hget("PRICE:".$period, "incall");
$outcall = $redis->hget("PRICE:".$period, "outcall");
$sentbytes = $redis->hget("PRICE:".$period, "sentBytes");
$receivedbytes = $redis->hget("PRICE:".$period, "receivedBytes");
$transport = $redis->hget("ADMIN:call", "transport");
$codec = $redis->hget("ADMIN:call", "codec");
?>
<br/>
<form action="callconfigop.php" method="post">
<h2>Call Configuration</h2>
<table border="1" width="50%">
<tr align='center' class="header">
<td>Configuration</td><td>Value</td>
</tr>
<tr align='center'>
<td>Transport Protocol</td>
<td>
<select name="transport">
<option value="rtp" <?php if ($transport == "rtp") echo "selected" ?>>rtp</option>
<option value="srtp" <?php if ($transport == "srtp") echo "selected" ?>>srtp</option>
<option value="zrtp" <?php if ($transport == "zrtp") echo "selected" ?>>zrtp</option>
</select>
</td>
</tr>
<tr align='center'>
<td>Codec</td>
<td>
<select name="codec">
<option value="gsm" <?php if ($codec == "gsm") echo "selected" ?>>gsm</option>
<option value="opus" <?php if ($codec == "opus") echo "selected" ?>>opus</option>
</select>
</td>
</tr>
<tr align='center'>
<td colspan="2"><input type="submit" value="Submit"/></td>
</tr>
</table>
<input type="hidden" name="period" value="<?= $period ?>"/>
</form>
<br/>
<form action="priceop.php" method="post">
<h2>Price Configuration</h2>
<table border="1" width="50%">
<tr align='center' class="header">
<td>Period</td><td><?= $period?></td>
</tr>
<tr align='center'>
<td>Outcoming Call</td><td>$<input type="text" name="outcall" value="<?= $outcall ?>"/> / second</td>
</tr>
<tr align='center'>
<td>Incoming Call</td><td>$<input type="text" name="incall" value="<?= $incall ?>"/> / second</td>
</tr>
<tr align='center'>
<td>Sent Text Message</td><td>$<input type="text" name="sentbytes" value="<?= $sentbytes ?>"/> / byte</td>
</tr>
<tr align='center'>
<td>Received Text Message</td><td>$<input type="text" name="receivedbytes" value="<?= $receivedbytes ?>"/> / byte</td>
</tr>
<tr align='center'>
<td colspan="2"><input type="submit" value="Submit"/></td>
</tr>
</table>
<input type="hidden" name="period" value="<?= $period ?>"/>
</form>
<br/>
<h2>User Configuration</h2>
<table border="1" width="100%">
<tr class="header"><td align='center'>Phone Number</td><td align='center'>Name</td><td align='center'>Email</td><td align='center'>Bill</td><td align='center'>Status</td><td align='center'>Action</td></tr>
<?php
foreach ($users as $user) {
	echo "<tr>";
	$phoneNumber = explode(":", $user)[1];
	echo "<td align='center'>".$phoneNumber."</td>";
	echo "<td align='center'>".$redis->hget($user, 'name')."</td>";
	echo "<td align='center'>".$redis->hget($user, 'email')."</td>";
	echo "<td align='center'><a href='userbill.php?phonenumber=".$phoneNumber."'>Show Details</a></td>";
	$status = "enable";
	if ($redis->hget($user, 'status') == "disable") {
		$status = "disable";
	}
	echo "<td align='center'>".$status."</td>";
?>
	<td align='center'>
	
<?php
if ($status == "enable") {
?>
enable &nbsp;
<a href="userop.php?user=<?= $phoneNumber ?>&op=disable">disable</a> &nbsp;
<?php
}
else {
?>
<a href="userop.php?user=<?= $phoneNumber ?>&op=enable">enable</a> &nbsp;
disable &nbsp;
<?php
}
?>
<a href="userop.php?user=<?= $phoneNumber ?>&op=delete">delete</a> &nbsp;
</td>
<?php
echo "</tr>";
}
?>
</p>
</body>
</table>
</html>