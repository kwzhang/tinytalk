<?php
$transport = $_POST["transport"];
$codec = $_POST["codec"];

require "../predis/autoload.php";
Predis\Autoloader::register();
$redis = new Predis\Client();

$redis->hset("ADMIN:call", "transport", $transport);
$redis->hset("ADMIN:call", "codec", $codec);
?>
<script>
    window.location.replace("admin.php");
</script>