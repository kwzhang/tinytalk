<?php
require "../predis/autoload.php";
Predis\Autoloader::register();
$redis = new Predis\Client();

$user = $_GET["phonenumber"];
$prices = $redis->keys("PRICE:*");
?>
<html>
<link href='../styles.css' rel='stylesheet'>
<body>
<p>
<h2>User: <?= $user ?> Billing Information </h2>
<table width="70%" border="1">
<tr class="header" align="center">
<td>Period</td><td>Incall</td><td>Outcall</td><td>Message Sent</td><td>Message Received</td><td>Total Cost</td>
</tr>
<?php
foreach ($prices as $price) {
    $period = explode(":", $price)[1];
    $incall = $redis->hget("CALL_HISTORY:".$user.":".$period, "inCallSecond");
    $outcall = $redis->hget("CALL_HISTORY:".$user.":".$period, "outCallSecond");
    $sentBytes = $redis->hget("TXTMSG_HISTORY:".$user.":".$period, "sentBytes");
    $receivedBytes = $redis->hget("TXTMSG_HISTORY:".$user.":".$period, "receivedBytes");
    if ($receivedBytes == "" && $sentBytes == "" && $incall == "" and $outcall == "") {
        continue;
    }
    if ($incall == "") {
        $incall = 0;
    }
    if ($outcall == "") {
        $outcall = 0;
    }
    if ($sentBytes == "") {
        $sentBytes = 0;
    }
    if ($receivedBytes == "") {
        $receivedBytes = 0;
    }
    $priceIncall = $redis->hget("PRICE:".$period, "incall");
    $priceOutcall = $redis->hget("PRICE:".$period, "outcall");
    $priceSent = $redis->hget("PRICE:".$period, "sentBytes");
    $priceReceived = $redis->hget("PRICE:".$period, "receivedBytes");
    $totalPrice = $priceIncall*$incall + $priceOutcall*$outcall + $priceSent*$sentBytes + $priceReceived*$receivedBytes;
    
?>
<tr align="center">
<td><?= $period ?></td><td><?= $incall ?> secs * <?= $priceIncall ?></td><td><?= $outcall ?> secs * <?= $priceOutcall ?></td><td><?= $sentBytes ?> bytes * <?= $priceSent ?></td><td><?= $receivedBytes ?> bytes * <?= $priceReceived ?></td><td>$<?= $totalPrice ?></td>
</tr>
<?php
}
?>
</table>
<a href="admin.php">back</a>
</p>
</body>
</table>
</html>