<?php
$AUDIO_DIR='D:\Apache24\htdocs\eval\audio';
?>